from django.shortcuts import render,HttpResponse


# Create your views here.

def add(request): #http get 方式
    a = request.GET['a']
    b = request.GET['b']
    c = int(a)+int(b)
    return HttpResponse(str(c))

def add2(request,a,b): #http get透過route與regex的方式將參數傳至方法

    c = int(a)+int(b)
    return HttpResponse(str(c))
