from django.db import models
from datetime import datetime
from django.utils.html import format_html

# Create your models here.

class Account(models.Model):
    username = models.CharField(max_length=20,
                            verbose_name='名稱',
                            default='')
    password = models.CharField(max_length=20,
                            verbose_name='密碼',
                            default='')
    permission = models.CharField(max_length=10,
                              choices=(('admin', '管理員'), ('user', '用戶'),('guest', '訪客')),
                              default='guest',
                              verbose_name='權限組')
    
    create_time = models.DateTimeField(default=datetime.now,verbose_name='創建時間')

    def __str__(self):
        return '{}'.format(self.username)

    class Meta:
        verbose_name_plural = '用戶資料'
		
class RealEstate(models.Model):
	
	orderid  = models.CharField(max_length=10,
                            verbose_name='編號',
                            default='')
	name  = models.CharField(max_length=20,
                            verbose_name='名稱',
                            default='')
	price = models.CharField(max_length=20,
                            verbose_name='價錢',
                            default='')
	owner = models.CharField(max_length=20,
                            verbose_name='所有者',
                            default='')
	permission = models.CharField(max_length=5,
                            verbose_name='讀取權限',
                            default='')
	create_time = models.DateTimeField(default=datetime.now,verbose_name='創建時間')