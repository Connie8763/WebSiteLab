from django.apps import AppConfig


class RegistConfig(AppConfig):
    name = 'regist'
