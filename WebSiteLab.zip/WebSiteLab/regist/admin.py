from django.contrib import admin
from regist.models import Account
# Register your models here.

admin.site.site_title =  'WebSiteLab'
admin.site.site_header = 'WebSiteLab BackEnd'

@admin.register(Account)
class Account_background(admin.ModelAdmin):
    list_display =  ('username','password','permission','create_time')
    search_fields = ('username',)
    list_per_page = 50