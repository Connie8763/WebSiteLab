from django.shortcuts import render,HttpResponse
from django.http import HttpResponseRedirect,Http404,JsonResponse
from django.template import loader

from .models import Account,RealEstate
from .sqliteDB import SqlDataBase
import uuid
# Create your views here.


def regist(request):
    template = loader.get_template('regist.html')
    return render(request,'regist.html')

def regist_service(request):
    username = request.POST['username']
    password = request.POST['password']
    permission = request.POST['permission']

    new_account = Account()
    new_account.username = request.POST.get('username',None)
    new_account.password = request.POST.get('password',None)
    new_account.permission = request.POST.get('permission',None)
    
    new_account.save()
    
    return HttpResponse('''
                           <p>UserName:%s</p>
                           <p>Password:%s</p>
                           <p>permission:%s</p>
                           <p>註冊成功! 此頁面將在5秒後跳轉至登入頁面!</p>
                           <script>
                               function myrefresh() {
                                    window.location.assign("http://127.0.0.1:8000/login")
                                }
                                setTimeout('myrefresh()', 5000);
                           </script>
                        '''%(username,password,permission))

def login(request):
    template = loader.get_template('login.html')
    return render(request,'login.html',{'LoginState':''})

def login_service(request):
    username = request.POST['username']
    password = request.POST['password']
    sqlData = SqlDataBase('regist_account')
    account_dict = sqlData.SelectAllData()
    data = {}
    if (username in account_dict) == True:
        if account_dict[username] == password:
            premission = sqlData.GetAccountPermission(username)
            data['is_taken'] = 'False'
            data['redirect'] = 'http://127.0.0.1:8000/manage?username={}&permission={}'.format(username,premission)
        else:
            data['is_taken'] = 'True'
            data['error_message'] = '密碼錯誤，登入失敗!'
    else:
        data['is_taken'] = 'True'
        data['error_message'] = '帳號錯誤，登入失敗!'
    return JsonResponse(data)

def load_real_estate_data(request):
    template = loader.get_template('real_estate_list.html')
    username = request.GET['username']
    user_permission = request.GET['permission']
    sqlData = SqlDataBase('regist_realestate')
    result = sqlData.GetResult(user_permission.lower(),username)
    entry_str = ''
    for row in result:
        entry_str += '''<tr class="clickable-row">
				    <td>{}</td>
				    <td>{}</td>
				    <td>{}</td>
				    <td>{}</td>
				    <td>{}</td>
				    <td>{}</td>
			</tr>'''.format(row[6],row[1],row[2],row[3],row[4],row[5])
    user_title = '{}-{}'.format(username,user_permission)
    return render(request,'real_estate_list.html',{'user_title':user_title,'AccountInfo':user_title,'DataList':entry_str})

def create_realestate_data(request):
    new_data = RealEstate()
    new_data.name = request.POST['name']
    new_data.price = request.POST['price']
    new_data.owner = request.POST['owner']
    new_data.permission = request.POST['permission']
    new_data.orderid = str(uuid.uuid1()).split('-')[0]
    new_data.save()
    data = {}
    data['Date'] = new_data.create_time
    data['OrderID'] = new_data.orderid
    data['Name'] = new_data.name
    data['Price'] = new_data.price
    data['Owner'] = new_data.owner
    data['OwnerPremission'] = new_data.permission
    data['is_create'] = 'True'
    data['message'] = '{}創建成功，編號{}'.format(new_data.name,new_data.orderid)
    return JsonResponse(data)

def delete_account(request):
    del_account_name = request.POST['username']
    
    delete_account_data = SqlDataBase('regist_realestate')
    delete_account_data.DeleteAccountData(del_account_name)
    delete_account_data.Close()
    delete_account = SqlDataBase('regist_account')
    delete_account.DeleteAccount(del_account_name)
    delete_account.Close()
    data = {}
    data['is_done'] = 'True'
    data['message'] = '刪除完畢'
    return JsonResponse(data)
