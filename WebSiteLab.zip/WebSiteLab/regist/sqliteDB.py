from datetime import datetime
from django.conf import settings
import sqlite3
import re

class SqlDataBase():
	def __init__(self,tableName):
		self.__path = settings.BASE_DIR + '/db.sqlite3'
		self.__table = tableName
		self.con = sqlite3.connect(self.__path)
		self.db = self.con.cursor()
	def SelectAllData(self):
		self.db.execute('SELECT * FROM {}'.format(self.__table))
		result = self.db.fetchall()
		account_dict = {}
		for row in result:
			account_dict[row[1]] = row[2]
		return account_dict
	def GetAccountPermission(self,username):
		self.db.execute(r'SELECT * FROM {0} where username == "{1}"'.format(self.__table,username))
		result = self.db.fetchall()
		if result == None:
			return 'Not Found'
		else:
			for row in result:
				return row[4]
	def GetResult(self,permission,username=''):
		if permission == 'admin':
			self.db.execute('SELECT * FROM {}'.format(self.__table))
		elif permission == 'user':
			self.db.execute('SELECT * FROM {} where permission == "user" or permission == "guest"'.format(self.__table))
		else:
			self.db.execute('SELECT * FROM {} where permission == "guest" and owner == "{}"'.format(self.__table,username))
		return self.db.fetchall()
	def DeleteAccountData(self,username):
		self.db.execute(r'DELETE FROM {0} where owner == "{1}";'.format(self.__table,username))
		self.con.commit()
		print("Command: " , r'DELETE FROM {0} where owner == "{1}"'.format(self.__table,username))
		return True
	def DeleteAccount(self,username):
		self.db.execute(r'DELETE FROM {0} where username == "{1}";'.format(self.__table,username))
		self.con.commit()
		print("Command: " , r'DELETE FROM {0} where username == "{1}"'.format(self.__table,username))
		return True
	def Close(self):
		self.con.close()
		return True
