"""WebSiteLab URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from django.conf import settings
from django.views.static import serve
from calc import views as calc_views
from regist import views as regist_views
from population import views as population_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('regist/', regist_views.regist),
    path('regist_service',regist_views.regist_service,name='regist_service'),
    path('login/', regist_views.login),
    path('create_realestate/',regist_views.create_realestate_data,name='create_realestate_data'),
    path('manage',regist_views.load_real_estate_data),
	path('delete/',regist_views.delete_account),
    path('login_service/',regist_views.login_service,name='login_service'),
    path('add',calc_views.add,name='add'), 
    path('search/',population_views.search,name='search'),
    url(r'^add/(\d+)/(\d+)/$',calc_views.add2,name='add2'),
    url(r'^static/(?P<path>.*)$',serve,{'document_root': settings.STATIC_ROOT}),
   
]
