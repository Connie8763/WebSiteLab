from django.apps import AppConfig


class PopulationConfig(AppConfig):
    name = 'population'
