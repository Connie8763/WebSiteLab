from django.shortcuts import render,HttpResponse
from django.template import loader
from .TCCReportCrawler import TCCReportCrawler

# Create your views here.


def search(request):
    YearChoose = '108'
    MonthChoose = '11'
    if request.method == 'POST':
        YearChoose = request.POST.get('YearChoose', '')
        MonthChoose = request.POST.get('MonthChoose', '')  
    crawler = TCCReportCrawler('全部','108','11')
    crawler.display_result()
    for i in range(1,crawler.get_page_nums()):
        crawler.next_page()
        crawler.display_result()
    template = loader.get_template('tcc.html')
    bar_title = '{}年{}月台中市人口'.format(YearChoose,MonthChoose)
    chart_data = ''
    label_list,data_list= crawler.get_population_data()
    
    for i in range(len(label_list)):
        chart_data += span_chart_database(label_list[i],data_list[i])
    content = {'chartTitle':bar_title,'Labels':bar_title,'data_dict':chart_data}
    return render(request,'tcc.html',content)

def span_chart_database(label,data):
    return '''{
                    label: "%s", 
                    data: [%s], 
                    backgroundColor: [
                        "rgba(255, 99, 132, 0.2)",
                    ],
                    borderColor: [
                        "rgba(255,99,132,1)",
                    ],
                    borderWidth: 1
                },''' % (label,data)
