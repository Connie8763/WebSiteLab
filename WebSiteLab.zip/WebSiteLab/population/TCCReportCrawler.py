import requests
import re
from bs4 import BeautifulSoup

'''
    require package:
    lxml ----- pip install lxml 
    bs4  ----- pip install beautifulsoup4   
'''

'''
    :object declare:
        crawler = TCCReportCrawler(name,year,month)
    :parameter
        name  ----- 區名
        year  ----- 年分
        month ----- 月份
    :method
        district_change(name)    ----- 更改區名
        date_change(year,month)  ----- 時間更改
        next_page()              ----- 下一頁
        display_result()         ----- 顯示當前頁面資料
        get_page_nums()          ----- 獲取頁數
'''
class TCCReportCrawler:
    def __init__(self,name,year='108',month='11'):
        self.url = 'https://demographics.taichung.gov.tw/Demographic/Web/TCCReport02.aspx'
        self.request_encoding = 'utf-8'
        self.headers = {
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Content-Length': '12005',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Cookie': 'ASP.NET_SessionId=lsplerp05ueqzza1eu2b0uth; style=S',
            'Host': 'demographics.taichung.gov.tw',
            'Origin': 'https://demographics.taichung.gov.tw',
            'Referer': 'https://demographics.taichung.gov.tw/Demographic/Web/TCCReport02.aspx',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 OPR/65.0.3467.62',
            'X-MicrosoftAjax': 'Delta=true',
            'X-Requested-With': 'XMLHttpRequest',
        }
        self.form_data = {
            'ctl00$ScriptManager1': 'ctl00$ContentPlaceHolder1$TCCCIVReport021$UpdatePanel1|ctl00$ContentPlaceHolder1$TCCCIVReport021$btnQuery',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_DIVPanel_St': 'Expanded',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox1_VI': '108',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox1': '108',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox1_DDDWS': '0:0:12000:24:225:0:-10000:-10000:1',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox1$DDD$L': '108',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox4_VI': '11',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox4': '11',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox4_DDDWS': '0:0:12000:186:225:0:-10000:-10000:1',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox4$DDD$L': '11',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox2_VI': '2',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox2': '和平區',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox2_DDDWS': '0:0:-1:-10000:-10000:0:-10000:-10000:1',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox2$DDD$L': '2',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox3_VI': '',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox3': '',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox3_DDDWS': '0:0:-1:-10000:-10000:0:-10000:-10000:1',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox3$DDD$L': '',
            'ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxGridView1_custwindowWS': '0:0:-1:-10000:-10000:0:1px:-10000:1',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxGridView1$DXSelInput': '',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxGridView1$CallbackState': 'BwIHAgIERGF0YQaBBwAAAAAbAAAAGwAAAAAAAAAPAAAAABoAAAAHYXJlYV9pZAdhcmVhX2lkAwAACW1pbGVfbmFtZQltaWxlX25hbWUHAAAGZ2VuZGVyBmdlbmRlcgcAAAJGMQJGMQMAAAJGMgJGMgMAAAJGMwJGMwMAAAJGNAJGNAMAAAJGNQJGNQMAAAJGNgJGNgMAAAJGNwJGNwMAAAJGOAJGOAMAAAJGOQJGOQMAAANGMTADRjEwAwAAA0YxMQNGMTEDAAADRjEyA0YxMgMAAANGMTMDRjEzAwAAA0YxNANGMTQDAAADRjE1A0YxNQMAAANGMTYDRjE2AwAAA0YxNwNGMTcDAAADRjE4A0YxOAMAAANGMTkDRjE5AwAAA0YyMANGMjADAAADRjIxA0YyMQMAAAVGMDAwMQVGMDAwMQcAAAVUb3RhbAVUb3RhbAMAAAAAAAAHAAcABwAHAAb//wMHAAcCBuWFqOmDqAcCA+ioiAMGtwIDBukDAwb0BQMGjQMDBoYDAwZoAwMGLwQDBgMFAwagBQMG/wQDBskEAwY7BQMGdgUDBjAFAwYVAwMGNQIDBo8BAwfeAwdaAwcYAwcHBwIFMTA4MTEDBrpHBwAHAAb//wMHAAcCBuWFqOmDqAcCA+eUtwMGYgEDBvABAwYDAwMGyQEDBuEBAwa2AQMGCAIDBlECAwaiAgMGXwIDBnACAwatAgMGxgIDBpUCAwagAQMGEwEDB6IDB1cDBy4DBw0DBwQHAgUxMDgxMQMGciMHAAcABv//AwcABwIG5YWo6YOoBwID5aWzAwZVAQMG+QEDBvECAwbEAQMGpQEDBrIBAwYnAgMGsgIDBv4CAwagAgMGWQIDBo4CAwawAgMGmwIDBnUBAwYiAQMH7QMHhwMHLAMHCwMHAwcCBTEwODExAwZIJAcABwAG//8DBwEHAgnlpKfoqqDph4wHAgPoqIgDB6kDB6EDB80DB4ADB5ADB4YDB8IDB+8DB+gDB9sDB8cDB9cDB9QDB70DB28DB1QDBzUDBygDBwwDBwIDBwAHAgUxMDgxMQMGfgsHAAcABv//AwcBBwIJ5aSn6Kqg6YeMBwID55S3AwdSAwdYAwduAwc/AwdIAwdDAwdeAwd3AwdvAwdgAwdtAwd5AwdpAwdgAwc9AwcsAwcNAwcPAwcFAwcBAwcABwIFMTA4MTEDBsAFBwAHAAb//wMHAQcCCeWkp+iqoOmHjAcCA+WlswMHVwMHSQMHXwMHQQMHSAMHQwMHZAMHeAMHeQMHewMHWgMHXgMHawMHXQMHMgMHKAMHKAMHGQMHBwMHAQMHAAcCBTEwODExAwa+BQcABwAG//8DBwEHAgnlpKfloqnph4wHAgPoqIgDB0gDB88DBhcBAweZAwePAweCAweVAweVAwe7AweuAwemAwe2AwegAwemAwdoAwdeAwdHAwclAwcOAwcGAwcBBwIFMTA4MTEDBlQKBwAHAAb//wMHAQcCCeWkp+WiqemHjAcCA+eUtwMHJAMHYAMHhgMHRwMHPQMHQQMHRwMHPQMHVgMHVgMHUwMHVwMHSQMHUwMHOAMHMwMHJAMHDAMHCQMHAwMHAQcCBTEwODExAwbtBAcABwAG//8DBwEHAgnlpKfloqnph4wHAgPlpbMDByQDB28DB5EDB1IDB1IDB0EDB04DB1gDB2UDB1gDB1MDB18DB1cDB1MDBzADBysDByMDBxkDBwUDBwMDBwAHAgUxMDgxMQMGZwUHAAcABv//AwcBBwIJ5Lit6I+v6YeMBwID6KiIAwfGAwe7AwdTAwdMAwdiAwdnAwd8AwfbAwfZAwexAwecAwerAwebAwemAwdYAwdAAwcuAwcSAwcKAwcCAwcABwIFMTA4MTEDBjYJBwAHAAb//wMHAQcCCeS4reiPr+mHjAcCA+eUtwMHaAMHXAMHLQMHKwMHNAMHOgMHLQMHYwMHZQMHXAMHVAMHYAMHUwMHRAMHNAMHHgMHFQMHBgMHBQMHAQMHAAcCBTEwODExAwaZBAcABwAG//8DBwEHAgnkuK3oj6/ph4wHAgPlpbMDB14DB18DByYDByEDBy4DBy0DB08DB3gDB3QDB1UDB0gDB0sDB0gDB2IDByQDByIDBxkDBwwDBwUDBwEDBwAHAgUxMDgxMQMGnQQHAAcABv//AwcBBwIJ5YWs5ZyS6YeMBwID6KiIAwciAwdSAwe0AwdhAwdOAwdDAwddAwdjAweYAwd1AwdwAweDAweKAwegAwdbAwc3AwchAwcXAwcJAwcCAwcBBwIFMTA4MTEDBtoGBwAHAAb//wMHAQcCCeWFrOWckumHjAcCA+eUtwMHEAMHLQMHWAMHLQMHKwMHHwMHMAMHMgMHQAMHNgMHNgMHPgMHSwMHUQMHMgMHGwMHEAMHDAMHBQMHAAMHAAcCBTEwODExAwZiAwcABwAG//8DBwEHAgnlhazlnJLph4wHAgPlpbMDBxIDByUDB1wDBzQDByMDByQDBy0DBzEDB1gDBz8DBzoDB0UDBz8DB08DBykDBxwDBxEDBwsDBwQDBwIDBwEHAgUxMDgxMQMGeAMCBVN0YXRlB5gHGgcAAgAHAAIBBwECAQcBAgEHAgIBBwMCAQcEAgEHBQIBBwYCAQcHAgEHCAIBBwkCAQcKAgEHCwIBBwwCAQcNAgEHDgIBBw8CAQcQAgEHEQIBBxICAQcTAgEHFAIBBxUCAQcWAgEHFwIBBwAHAAcBBwAHAQcBBwAFAAAAgAkCAAkCAAIAAwcEAgAHAAIBBwAHAAIBBwAHAA==',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxGridView1$DXSyncInput': '',
            'DXScript': '1_42,1_75,2_34,2_41,2_33,1_68,1_65,2_36,2_27,1_52,1_66,3_8,3_7,2_39',
            '__EVENTTARGET': '',
            '__EVENTARGUMENT': '',
            '__VIEWSTATE': 'zsy1tIYR2LPKzniKzpOCgLhBvSsES3RNF0l9zzFEvUBQCA2x8QgSbwFhgfOjir0U5eQHJXWXbDMzWkPu1jcukAUKzJLusSu77ZKLS0ZzZw0z/nZjMvt9wHpv9faeBXxx38AmJzL0pItMWONC2AOZR2xNJdUDGXgemcycXS4CHDdA+0Zbaa10lulWFJLarFeJtxxauE9rXvIGuAw8zhXgfes/YmdgmJTvvD6TSNKk76h1UjwNjMV7jd5jbqdEbswSyKbCSSkp4LLfT9e1tuODAVvR7mP/1vsQG9WLMqZYMU+qvsHItPtPG5L6Q9vCOYQ61pQ5YCVhYfRh9fVqCDFzl3fnWce7BDIR6qJKzA4SpO5hKe0IE9DhWoX8uZz1XwaawW5uyeo+UsRx6ooOKIo4hsDlYUqM+jZbK1OtF1xm87dogzMfOzhnpNZuPagvpGMlp3m87jCc9FKYwkXUEDnf5+ys3JlbrEtU5UEeq/qMw3PIfKaO8d9SC58/rJy/t8FQWSYDLdUcfvYeDtGHE/7GWMhrOcmVQUCXRWg9qguAgtlMqo46cMLkkZ8E8qXQdsbzH5kE3prSFKdDTkiHaGg+nyUwQ9ftvtEX50XRlkg+21PRFTW5S3wjiYxg33G9nzFEBvdS3XUtq5YkdNLuz7YLzngOqNMqCth9/y3tz8nxfWrzhbhzRs6bAxXUjcpLw631E/5vCyK6gbh/L1x6QYJK5VSp0TGaZlwej5eN/Ko462ZyMx/oLBWqZlvyrxxe3CGUmcmqXgu2RztCp9/zihCqx9L97fMrcbXZCxmKdPHkVnR+9iRxodWiDe8HVxkXHZllZY9iH0wUMxejLiabvlDpQ8JBHFLe+F0AlC3OZlc3mlhc/4MYQNkMhzb9s7GslNzep3/zX9H3QRmHyf6KqpE/iRKawILCKqwc0b/YhgontJYtFLtyyaooRL2B2rWzTxJ7neJ5g/i0R0DaKSi2GcEyWjxF05yvBa06irN5vgL+2m1Tn9DReHZotGzD77y2YH71DE+hLx3XnWo+Kl3WFfK19ZwTt8dxNxW9HusD7wllwPTu/TCIih2RB8xEdFwLj1i/X0LYlWhcsQVsKw69SZ1IYRUtsnKxfw48GuwFbUSckV25sX6kPb7VAHLxGC/XMC314O5ag+9opt2StXVMY65EzfQqNX8sgFU2g4NHtF1Vy3+GhWBANuEMRqF3sVGcOvObmiXtT3w8XlRcuRI5CuPMH0GiPxgSKSKPQ1VlbbV2ehmeEfeuPWupCIDii9dKh3xGJ15g+Ey+iFxLOU8mX3LHNZLjCGlRf8wjoDCBDnTS0WsyO+5IEWUoNBUbFWX5xAf0Xjx/FCTYy38Wcyu7KbYuJxjJ58Fgc8uH5lYDrSSbkP2bh3uLuLFyiRW52ykvDJqZnNHPzGlT9Oig3Or19dtDY1kjwj83GMeKRJazi0kKCNajjBVWe1I0Q5jdkRhcAMtUaYNVWhdyrDcEWWx8Pmm8Wu2tRddlg2Qic0Ys9F6jKE2cNMmUxh/F7SvC2BMFp8lTLUOVzj/JzWnK1KI7wsXD5vMg/fWb/OT8Awdwh5Gc9h6waSUzux/sGHNMWNIoAIEb5Oesmif9RBXj1+jo4NxUhSer8pn7Wm+wfl829s9k2FY2k3zsR+p0SC/bT7NKn3jc9x9Vg0KNxyaLruYqSY44mshnbZylDoXFH+kpZPlNUeQr2WHYt74pL6h2Mmfdd2+JwUA22a9Qa9RohcGEhIVBzgJp0aaKOESLoYgux5uLSVWBbI4nKnGmSuPEIIqtoPR4o51MBfzXFycvsN8t+tM+YcTLErcBOjFErf6SWRIngYg7Ka7BFPDUErDubrSQgOZkUuxYC7ngfnduGHJK1YVUhK74/ffGhxrDBPYFY2O9foMS4lGSQbmnbL8f7Et4D2onPaWlTZVG8TUrH4TzqPZMqdTKP68Oeq3WSzfMHpKqAsycmdMz9d69FSby7ObeyRb2jeVqHutJG978WXvnTYDLX0hnp/T5BIkVGnmI9aDDZl6HktFycpFk+sskCkkC+S6u9biiYVFw99tzChuvU+BmaGq9qDL8N4Upz0ehEVpUnIF8+ClGVXoGteh8PCrhwFZUlPsUeO+NrDYdTcfSc/Y4KmoAXhmhbCldbGZKSk+u/wKIEY5zkpCB1kEn725anTlSmrYBHQ/XxaC2TuRayDb8t2T2ABys6TeAj4Zz02S2J984Z1ZRBdt9Om+RHdfeLdbQ0hKLY4pLdAg8GnldI3xZ7uxubVdOwBWknU0YVlbQq0bjLfPxMli3ryx82JXB37YnJab5TKhrbhf110z6WMP//gcMDHZTrc4A3LJyOCWdGjCqlDLRjtH+vs+Qc/9DGKBDmnXsLxLvnNTNsjL+uM63T0ZZXKuGC0OKt6xQ84ZcIsZzqDc32I1Ou6GLuyCZtjrS9u5FhWWEwgYsn21NNMdTPG/eighyAI/O5V6X6jc+Q9ibnMU/wedNWKbzVcDBC8wcS59wp4IYo8H5n7uK60VcI74X9O0DMxh53WFOlB/IXZhCkh1wR73bWBvZVE4TEVEEQI34UzY7kT92dCkshL2XuT9OrqWrEGfBs1Jqpmkov1z95f6snpGjyzEo8b7IUuBcanFqlVMAMMa4WbBi8pvGHNyXZdub9s1q5MXZLeNC3iPl5erVQ5IE3uw+uGCokl1wpLACf9Ay0yTk14oTflkQoDv3N79qtbskxC/lS+NiWMsXWi+p5FjYz7wsZipzbUbW4kDUo6N9SiYWzSBvrw/dZAxm47m3WhvdwYyvtfQZIhltMFpJWcKsFNl1udcRbbn4t9n1ca0X+XDr5+YVj5NIOJ/lEfpxNwf6mQwhL9SG0cRvcNwcpZ1P7mVANbxBHwUc4YuTqMCwHJXO9utwG9JnwYeClGAVoSfsuTkv+FQgC+0s1YomMHKMm4A6IzXgfitv/xSzC9SW2IIQ6xgHhsi/hcV6mycU/PtnRM9/56GG01L3HAbd7ARRYBIIcB/cbzAYPBGYTSi1OGgAjMsbEYOGDyn03FECtKaRRFMMQQfs2leWTrV/yLf5tkZcwfVO//SL7sJjMzozIncbh2DXwJOBPsoiWRAEO5vU5ILQNcfylmxUBF95bWfxBMJkEEAEtY1G0kVvuqNLFCr/gRCNpYWia4dNVTzbjb4GKMZZzX9vgvgVUyPQYJXSlC4+qXL5Ty55HP+7G8JcrK/SyrQlPm9auajky83v6PdA4c5t4B0x6XNsXPFfylMUisOjNg09KozGqAh8Bm1dPV9zV4sUNpyhwV5t7MCrfml+uSiiXzAh9fbmgk7NYEmDeAx8gsSqGWpzAcjVfWBlV5ZHqoJTY49DU3Lin69etfHtNN6hDhaDwH1zLbjBTKOIOPcSoY2eFIlQSMfKi/di20s4v5JEzB5VJeZWuQDYA9/5PVkJPXlI6Xi2eFnGPKpI1eX4lEfcgj5mlZrNQOxWQDKCZkx/Fh1pENobgPnzKIyEmzqcTkrREiegxgJ3gY8LN2WmBeSKSH6GcbujAMuUKjzelWoCc8b8oCuvhTnsKRtTZoxM5iPMLzYPnflZNDQWGWX45ukbqYsA0mSFgBOCscmL2UlTyphPDzfaNTQ4zagDe7Vd3IvnaZZoHYdjVntBfrhMiVySYYtDU3eVeDExGjjGMh50A1jj8RAGKTN6CVHeTN+ZPeOkEaLM2xsz7XkI/HBXKMXtvFYGv7KCed0r+6TtaaP1lzlmqYI9U55v+qvGp1ZbGF+bbY5EVqiENCkrjOG3zwKSbqnMOb/7JCdSAfG7ZLHAsTIuu66JfZWKrtFkaeBfprdQNCDaCfOvnyWi5vorLXK6JD7LkXBz6Ao09o1U7dRBm75sawnzJVDROZ7IagJoBqNhagZeOfIL9nOVBRv4Udwi90S2w1fp+uvK8x/QtZ2iNlnXM4vJdNsnln7Xjh1Q970O3NU6ETEsTAbpuVwnW29aX6m4hgGb5WGDBBwUVLWHUZd2hV2BUENk1J3D3Xf60x1vBIcJK86HkNJEYmbz7prtiTfNiSWzdlnjRUlzdByYuy6Zd8ztYdJoioh3tdqUKOWnLlMXGJg5kH7bO5zwxAfj9RteKeZorM+mlVkrdGC/x8hClMn9zs86H9s/wjBVsKMqvuCu1r3U1hm9RRI5ghgzFCLJzkbC5BrYEkhdYGUkvZtUtuE97W8qXbKoUYek0jxy4hBkCYz14WoZhtHEpRoPBSyh1AyXVht8NZYCmMQs5ZsnXq+KEI1PVdecqR16hFGVzAu35M2FmOfnrxR/BXZF+t6YKyYdPxx6AUFxnUzu3OY4oAvKrTVZXZHkJKacv/B9Uaj3FTA275UxoUn9J79kA5x4RWbS0bpJWQSZdWWp5m9jW2x9yqLiU55P08OWXrFIKIk+w5cDtCukn1Vo+7vhwmWRxYsYTw9wx/4aUMWBPhKPHv2Rr/QHfs5BrI+RDPTOh6PrJWYEsNXLjWef8OPJgOHbxeHDNfE6FfqPu7Q4sese5YS3tta2nxx9e6mR8NtNnvkwcjyJlc7TrY39xubRougRWnDdKa5Da8Hg4VppBy0y97nFxlXMmqMtlIt08jsbpgyfVhRsESphsgF9PIZmwe3eH9OkR0kDttLFp6VOAzGlgbuBrkKVivQDjxy+ca8FUjfYtUq92dDED8BT/U+PBdl/jgQKsGFwZZR6juWuhnk5jPDSd8ps4+4nzcBZwoRYo8m2shOcweZUhPihx9/GmtvAC3muk7Ox6BCRggjh/T3mEaHSBUb1wCbxVzySHXN+qreoi8YUXQPjA+3ghy1hRNt58J+6epHLnbqxy7IOJgzcS0ekhxuWKXGvXlpmIBy/ajCQmhXwxwMSqVzqxNdxTsu/IJEOw29o1kyEP4D8Fi6DWGc0yrsiwG72MviW0osCMk7+ub6diyf1jCFI4FAyIgivXhYOLJiTDN7jGsOBQw8BAtvSL9uahXloEKYnT24hSDWCOe6rj+DuCn8Rz2lRh56D54aitzAZqO+O5eIdV+aLqeWXGetoRAbq4W7UzZ9oApbEahyrY2zqf2bjeuKHyM7Rfhoav6RWCcTuw1shfatJEmR9SimvqEfGbBMAj8T7if0mnX8usPiR/FPyOXC1hqEuBlR3kfhYo749zvnCjHH/vvXKq76r/OM7waGOhEzFo3O3jfLG0wBSbYi4FOdZ6I6BEbX4HiRaF9tOKt3S8fiOdbEz1jV87SBWuZ0u5TSy27pFdGuq++hj0Vji3Y0iEX9g8byIC9RAU+ynQRcrxscC+Gog97tFxtVoNbExfftm6rR9s//jNw55ZJ0COf3vJzZYV2p4VflHShni/w1SF6l2RU6NR6zmNlvMvLa5idVvLYsHou6E7gNkYXONgG3i+roocATSuOYHyVSZ7bJHOxrnC4Gu+EM6z2waAV9HSFTJm1fc8haTZZPR/GbvV4XRCu2IryB4KN2KWsXhOQ4qoa0sgMqRFjbMp/SgRMehGHXIgcKNdd4ZmLj6XRakLR+2iCJWIzo7Sw/5RDRhn0mUPGreHzOukoLlrd0NFdxUtCDRAftqhhsYnVGM/qjyU/9+HdIVj4KD8RAUf8Lx/kXwRAcLx+1iV9Nt8sA2asMucHO5MVF4r8Z/8bN3xRa+mvLySEVh1AVICNqn6hL0VeK/wVsT8UWtUDvxAEmrsGG+dHNvkZaqHv4XgOX3TQ0ibee1jO2zj4JvB4rn+9MDAPgsf8xyJNPpVELDOZ13gp2XDPIFPAanQQt3tk0v9rp/dC7ro60EwbCSbytACYB5iUEbJXDZEevrLx+PoJGI+6GKkwRBGutoa9vGdy6SKI+9i1JTbnkE8fInJgG4JKzWar9NKihb8EgN9J10P4jYzKGuKH/RMqpwySOcKdKiPo4Qq0Q=',
            '__VIEWSTATEGENERATOR': '6D131B3A',
            '__SCROLLPOSITIONX': '0',
            '__SCROLLPOSITIONY': '0',
            '__EVENTVALIDATION': 'w/Xc7knJaaF3hI8s7wAWnd2Tua4L+7cnX34Cr6+ZDvoeAYrw/rcPPWuHmpMdAKoUzfITJuil2Cq7C0TFSsITwOaCTlslcrlktaDfSvz7MyvyH+uBUOgGGTx4PFxWEzYs7TWeKm3qqFzpqbAC1hgwRN7hBszMGuf08m/+8Q==',
            '__ASYNCPOST': 'true',
            'ctl00$ContentPlaceHolder1$TCCCIVReport021$btnQuery': '',
            '__CALLBACKPARAM': 'c0:GB|20;12|PAGERONCLICK3|PN0',
        }
        self.district_dict = {
            '全部':'0',
            '中區':'1',
            '東區':'2',
            '南區':'3',
            '西區':'4',
            '北區':'5',
            '西屯區':'6',
            '南屯區':'7',
            '北屯區':'8',
            '豐原區':'9',
            '東勢區':'10',
            '大甲區':'11',
            '清水區':'12',
            '沙鹿區':'13',
            '梧棲區':'14',
            '后里區':'15',
            '神岡區':'16',
            '潭子區':'17',
            '大雅區':'18',
            '新社區':'19',
            '石岡區':'20',
            '外埔區':'21',
            '大安區':'22',
            '烏日區':'23',
            '大肚區':'24',
            '龍景區':'25',
            '霧峰區':'26',
            '太平區':'27',
            '大里區':'28',
            '和平區':'29',
        }
        self.labels =  ['區域別','里名','性別','總計']
        self.labels += [str(x)+'-'+str(x+4)+'歲' for x in range(0,95,5)]
        self.labels += ['100歲以上']
        self.district_name = name
        self.search_years = year
        self.search_month = month
        self.total_pages_pattern = re.compile('\d+\/(\d+)', re.IGNORECASE)
        self.current_page = 0
        self.total_page = 0
        self.form_data['ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox2'] = self.district_name
        self.form_data['ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox2_VI'] = self.district_dict[self.district_name]
        self.form_data['ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox2$DDD$L'] = self.district_dict[self.district_name]
        self.form_data['ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox1_VI'] = self.search_years
        self.form_data['ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox4_VI'] = self.search_month
        self.labels_list = []
        self.ppls_list = []
    def district_change(self,name):
        self.district_name = name
        self.form_data['ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox2'] = self.district_name
        self.form_data['ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox2_VI'] = self.district_dict[self.district_name]
        self.form_data['ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxComboBox2$DDD$L'] = self.district_dict[self.district_name]

    def date_change(self,year,month):
        self.search_years = year
        self.search_month = month
        self.form_data['ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox1_VI'] = self.search_years
        self.form_data['ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxComboBox4_VI'] = self.search_month

    def next_page(self):
        if self.current_page == self.total_page:
            return -1
        self.current_page += 1
        self.form_data['__CALLBACKPARAM'] = 'c0:GB|20;12|PAGERONCLICK3|PN{0};'.format(self.current_page)
        self.form_data['__CALLBACKID'] = 'ctl00$ContentPlaceHolder1$TCCCIVReport021$ASPxGridView1'

    def display_result(self):
        self._send_request()
        self.total_page = int(self.total_pages_pattern.findall(self.response.text)[0])
        soup = BeautifulSoup(self.response.text, 'lxml')
        soup = soup.find('table', id='ctl00_ContentPlaceHolder1_TCCCIVReport021_ASPxGridView1_DXMainTable')
        print(self.search_years,'年',self.search_month,'月 ','區名: ',self.district_name,'頁數: ',self.current_page+1,'/',self.total_page)
        #for label in self.labels:
            #print('%8s' % label,end='')

        for entry in soup.select('tr'):
            current_district_name = ''
            is_total = False
            for element in entry.select('td'):
                if element.text == '':
                    break
                if element.text in self.district_dict:
                    current_district_name = element.text
                if is_total == True:
                    self.labels_list.append(current_district_name)
                    self.ppls_list.append(element.text.replace(',', ''))
                    break
                if element.text == '計' and current_district_name != '':
                    is_total = True

                #print('%8s' % element.text,end='')
            #print('')

    def get_population_data(self):
        return self.labels_list,self.ppls_list
    def get_page_nums(self):
        return self.total_page

    def _send_request(self):
        self.response = requests.post(self.url, data=self.form_data, headers=self.headers)
        self.response.encoding = self.request_encoding



if __name__ == '__main__':
    crawler = TCCReportCrawler('全部','108','11')
    crawler.display_result()
    for i in range(1,crawler.get_page_nums()):
        crawler.next_page()
        crawler.display_result()
    labels,data = crawler.get_population_data()
    print(labels)
    print(data)
